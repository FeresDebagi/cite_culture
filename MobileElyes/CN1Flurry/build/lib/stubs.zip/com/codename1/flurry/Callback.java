package com.codename1.flurry;


/**
 * 
 *  @author Chen
 */
public class Callback {

	public Callback() {
	}

	public static void onClicked() {
	}

	public static void onClose() {
	}

	public static void onDisplay() {
	}

	public static void onAppExit() {
	}

	public static void onRendered() {
	}

	public static void onError(String err) {
	}

	public static void onFetched() {
	}

	public static void onVideoCompleted() {
	}
}
