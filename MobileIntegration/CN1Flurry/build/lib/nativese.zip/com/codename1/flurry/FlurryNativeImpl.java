package com.codename1.flurry;

public class FlurryNativeImpl implements com.codename1.flurry.FlurryNative{
    public void logEvent(String param, boolean param1) {
    }

    public void setAge(int param) {
    }

    public void setUserID(String param) {
    }

    public void endSession() {
    }

    public void initFlurry(String param) {
    }

    public boolean isAdReady() {
        return false;
    }

    public void setLogEvents(boolean param) {
    }

    public void displayAd() {
    }

    public void onPageView() {
    }

    public void setGender(String param) {
    }

    public void destroyAd() {
    }

    public void fetchAd() {
    }

    public void startSession() {
    }

    public void setAdSpaceName(String param) {
    }

    public void endTimedEvent(String param) {
    }

    public void setCrashReportingEnabled(boolean param) {
    }

    public boolean isSupported() {
        return false;
    }

}
