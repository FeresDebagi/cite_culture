namespace com.codename1.flurry{

using System;
using System.Windows;

public class FlurryNativeImpl {
    public void logEvent(String param, bool param1) {
    }

    public void setAge(int param) {
    }

    public void setUserID(String param) {
    }

    public void endSession() {
    }

    public void initFlurry(String param) {
    }

    public bool isAdReady() {
        return false;
    }

    public void setLogEvents(bool param) {
    }

    public void displayAd() {
    }

    public void onPageView() {
    }

    public void setGender(String param) {
    }

    public void destroyAd() {
    }

    public void fetchAd() {
    }

    public void startSession() {
    }

    public void setAdSpaceName(String param) {
    }

    public void endTimedEvent(String param) {
    }

    public void setCrashReportingEnabled(bool param) {
    }

    public bool isSupported() {
        return false;
    }

}
}
